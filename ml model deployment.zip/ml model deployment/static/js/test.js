var questions=[
    {
    que:"How has your appearance affected or influenced your behavior in the past few days?",
    a:"Neat and appropriate",
    b:"Slightly disordered",
    c:"Poor grooming and hygiene",
    d:"Extremely disorganized"
    },
    {
    que:"How is your mood in last 24 Hours?",
    a:"Calm and peaceful",
    b:"Slightly sad or anxious",
    c:"Depressed or anxious",
    d:"Extremely disturbed or isolated" 
    },
    {
    que:"How have your affect (Emotional Expression) been influenced or impacted?",
    a:"Appropriate and consistent",
    b:"Mildly restricted or uniform",
    c:"Markedly restricted or pointless",
    d:"Inappropriate or unstable"
    },
    {
    que:"How has your thought process been shaped or evolved in the last 24 hours?",
    a:"Logical and understandable",
    b:"Slightly tangential or uncertain",
    c:"Loosely associated or focused",
    d:"Disorganized or confused"
    },
    {
    que:"How has the content of your thoughts shifted or developed in past few days?",
    a:"No delusions or obsessions",
    b:"Mildly doubtful or obsessive thoughts",
    c:"Strongly doubtful or strange delusions",
    d:"Severely disorganized or suicidal ideation"
    },
    {
    que:"What was your perception regarding certain situations or individuals?",
    a:"No hallucinations or illusions(No perceptual abnormality)",
    b:"Mild perceptual distortions",
    c:"Distinct auditory or visual hallucinations",
    d:"Severe and distressing hallucinations"
    },
    {
    que:"How has your cognitive orientation?",
    a:"Fully oriented to time, place, and person",
    b:"Slightly disoriented to time or place",
    c:"Disoriented to time, place, and person",
    d:"Profound disorientation"
    },
    {
    que:"What do you think about your Cognitive (Memory)?",
    a:"Intact immediate and recent memory",
    b:"Mildly impaired immediate or recent memory",
    c:"Clearly impaired immediate and recent memory",
    d:"Severe memory impairment"
    },
    {
    que:"How was your attention and concentration in past few days?",
    a:"Normal attention and concentration",
    b:"Mildly distracted or difficulty maintaining attention",
    c:"Clearly impaired attention and concentration",
    d:"Severe inability to focus or maintain attention"
    },
    {
    que:" What is your Judgement (Decision) be like?",
    a:"AGood insight and judgment",
    b:"Some insight with minor judgment issues",
    c:"Limited understanding with impaired judgment",
    d:"Deep lack of understanding and severely impaired judgment"
    },
    {
    que:" How has your mental flexibility been?",
    a:"Able to adapt to changing situations",
    b:"Mild difficulty with changes",
    c:"Significant toughness in thinking",
    d:"Profound inability to adapt"
    },
    {
    que:"How is your language and communication?",
    a:"Normal language and communication skills",
    b:"Mild difficulties in expressive or approachable language",
    c:"Significant impairments in language and communication",
    d:"Profound difficulties in language and communication"
    },
    {
    que:" How are your Motor Activities (Body Motion)?",
    a:"Normal motor coordination and function",
    b:"Mild motor coordination difficulties",
    c:"Significant motor coordination impairments",
    d:"Profound motor coordination difficulties"
    },
    {
    que:"How is your social interaction in last 24 hrs?",
    a:"Appropriate social interaction",
    b:"Mild difficulties in social interaction",
    c:"Significant impairments in social interaction",
    d:"Profound difficulties in social interaction"
    },
    {
    que:"What do you think about self-care and functioning?",
    a:"Independent in self-care and functioning",
    b:"Mild difficulties in self-care and functioning",
    c:"Significant impairments in self-care and functioning",
    d:"Profound inability to perform self-care"
    }  
];
var count=-1;
var size = 15; // Specify the size of the array
var intArray = new Array(size).fill(0);


var radioButtons = document.querySelectorAll('.answer');

// Add change event listener to each radio button
radioButtons.forEach(function(radioButton) {
    radioButton.addEventListener('change', function() {
        // Get the value of the selected option
        var selectedValue = document.querySelector('input[name="answer"]:checked').value;
        var intValue = parseInt(selectedValue)
        intArray[count]=intValue;
    });
});

function loadque()
{
         if(count<questions.length-1)
             {
                 count++;
                 document.getElementById("submit").style.backgroundColor = "cornflowerblue";
                 document.getElementById("question").innerHTML = questions[count].que;
                 document.getElementById("a_text").innerHTML = questions[count].a;
                 document.getElementById("b_text").innerHTML = questions[count].b;
                 document.getElementById("c_text").innerHTML = questions[count].c;
                 document.getElementById("d_text").innerHTML = questions[count].d;
                 document.getElementById("submit").innerHTML = "Next";
                 document.getElementById("a").checked = false;
                 document.getElementById("b").checked = false;
                 document.getElementById("c").checked = false;
                 document.getElementById("d").checked = false;
                 if(count==questions.length-1)
                     document.getElementById("submit").innerHTML = "Submit";
                 if(count>=0)
                     {
                         document.getElementById("prev").style.opacity = "1";
                         document.getElementById("prev").style.cursor = "pointer";
                     }
             }
         else
         {
              let html=document.getElementById("submit").innerHTML;
              if(html=="Submit")
              {
                   const value = intArray;
                   $.ajax({
                   url: '/process',
                   type: 'POST',
                   contentType: 'application/json',
                   data: JSON.stringify({ 'value': value }),
                   success: function(response) {
                       document.getElementById('submit').innerHTML = response.result;
                       document.getElementById("submit").style.backgroundColor = "Red";
                   },
                   error: function(error) {
                       console.log(error);
                   }
                   });
              }
              if(html=="view result")
              {
                   $.ajax({
                   url: '/redirect',
                   type: 'GET',
                   success: function(response) {
                   // Optionally handle the response
                          window.location.href = "/result";
                    },
                    error: function(error) {
                           console.error('Error:', error);
                    }
                   });
              }
          }
};
function loadprev()
{
       if(count>0) 
           {
                document.getElementById("question").innerHTML = questions[count-1].que;
                document.getElementById("a_text").innerHTML = questions[count-1].a;
                document.getElementById("b_text").innerHTML = questions[count-1].b;
                document.getElementById("c_text").innerHTML = questions[count-1].c;
                document.getElementById("d_text").innerHTML = questions[count-1].d;
               count--;
               if(count!=questions.length-1)
                     document.getElementById("submit").innerHTML = "Next";
               
           }
        else{
            document.getElementById("prev").style.opacity = "0.6";
            document.getElementById("prev").style.cursor = "not-allowed";
        }
};
function Exit()
{
       if (confirm("Do you want to exit?") == true)
            window.location.href= "/";
};

