import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.svm import SVC
from sklearn.preprocessing import OrdinalEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pickle

data = pd.read_csv('survay_dataset.csv')
ordinal_encoder = OrdinalEncoder(categories=[['Well-groomed and appropriate', 'Slightly disheveled',
                                              'Poor grooming and hygiene', 'Extremely disorganized']])
data["Apperance and Behavior"] = ordinal_encoder.fit_transform(data[["Apperance and Behavior"]])
ordinal_encoder = OrdinalEncoder(categories=[['Calm and euthymic', 'Slightly sad or anxious',
                                              'Depressed or anxious', 'Extremely agitated or detached']])
data["Mood (In last 24 Hours)"] = ordinal_encoder.fit_transform(data[["Mood (In last 24 Hours)"]])
ordinal_encoder = OrdinalEncoder(categories=[['Appropriate and congruent', 'Mildly restricted or flat',
                                              'Markedly restricted or blunted', 'Inappropriate or labile']])
data["Affect (Emotional Expression)"] = ordinal_encoder.fit_transform(data[["Affect (Emotional Expression)"]])
ordinal_encoder = OrdinalEncoder(categories=[['Logical and coherent', 'Slightly tangential or circumstantial',
                                              'Loosely associated or perseverative',
                                              'Disorganized or incoherent']])
data["Thought Process"] = ordinal_encoder.fit_transform(data[["Thought Process"]])
ordinal_encoder = OrdinalEncoder(categories=[['No delusions or obsessions',
                                              'Mildly paranoid or obsessive thoughts',
                                              'Strongly paranoid or bizarre delusions',
                                              'Severely disorganized or suicidal ideation']])
data["Thought Content"] = ordinal_encoder.fit_transform(data[["Thought Content"]])
ordinal_encoder = OrdinalEncoder(categories=[['No hallucinations or illusions (No perceptual abnormality)',
                                              'Mild perceptual distortions',
                                              'Distinct auditory or visual hallucinations',
                                              'Severe and distressing hallucinations']])
data["Perception"] = ordinal_encoder.fit_transform(data[["Perception"]])
ordinal_encoder = OrdinalEncoder(categories=[['Fully oriented to time, place, and person',
                                              'Slightly disoriented to time or place',
                                              'Disoriented to time, place, and person',
                                              'Profound disorientation']])
data["Cognition (Orientation)"] = ordinal_encoder.fit_transform(data[["Cognition (Orientation)"]])
ordinal_encoder = OrdinalEncoder(categories=[['Intact immediate and recent memory',
                                              'Mildly impaired immediate or recent memory',
                                              'Markedly impaired immediate and recent memory',
                                              'Severe memory impairment']])
data["Cognition (Memory)"] = ordinal_encoder.fit_transform(data[["Cognition (Memory)"]])
ordinal_encoder = OrdinalEncoder(categories=[[
    'Normal attention and concentration',
    'Mildly distracted or difficulty sustaining attention',
    'Markedly impaired attention and concentration',
    'Severe inability to focus or sustain attention']])
data["Attention and Concentration"] = ordinal_encoder.fit_transform(data[["Attention and Concentration"]])
ordinal_encoder = OrdinalEncoder(categories=[[
    'Good insight and judgment',
    'Some insight with minor judgment issues',
    'Limited insight with impaired judgment',
    'Profound lack of insight and severely impaired judgment']])
data["Judgement"] = ordinal_encoder.fit_transform(data[["Judgement"]])
ordinal_encoder = OrdinalEncoder(categories=[[
    'Able to adapt to changing situations',
    'Mild difficulty with changes',
    'Significant rigidity in thinking',
    'Profound inability to adapt']])
data["Mental Flexibility"] = ordinal_encoder.fit_transform(data[["Mental Flexibility"]])
ordinal_encoder = OrdinalEncoder(categories=[[
    'Normal language and communication skills',
    'Mild difficulties in expressive or receptive language',
    'Significant impairments in language and communication',
    'Profound difficulties in language and communication']])
data["Language and Communication"] = ordinal_encoder.fit_transform(data[["Language and Communication"]])
ordinal_encoder = OrdinalEncoder(categories=[[
    'Normal motor coordination and function',
    'Mild motor coordination difficulties',
    'Significant motor coordination impairments',
    'Profound motor coordination difficulties']])
data["Motor Activity"] = ordinal_encoder.fit_transform(data[["Motor Activity"]])
ordinal_encoder = OrdinalEncoder(categories=[[
    'Appropriate social interaction',
    'Mild difficulties in social interaction',
    'Significant impairments in social interaction',
    'Profound difficulties in social interaction']])
data["Social Interaction"] = ordinal_encoder.fit_transform(data[["Social Interaction"]])
ordinal_encoder = OrdinalEncoder(categories=[[
    'Independent in self-care and functioning',
    'Mild difficulties in self-care and functioning',
    'Significant impairments in self-care and functioning',
    'Profound inability to perform self-care']])
data["Self-Care and Functioning"] = ordinal_encoder.fit_transform(data[["Self-Care and Functioning"]])

df = pd.DataFrame(data)
df['Risk level'] = df['Apperance and Behavior'] + df['Motor Activity'] + df['Affect (Emotional Expression)'] + df[
    'Thought Process'] + df['Thought Content'] + df['Perception'] + df['Cognition (Orientation)'] + df[
                       'Cognition (Memory)'] + df['Attention and Concentration'] + df['Judgement'] + df[
                       'Language and Communication'] + df['Mental Flexibility'] + df['Social Interaction'] + df[
                       'Motor Activity'] + df['Self-Care and Functioning']

bins = [0, 1, 9, 18, 27, 36, 46]

# Define labels for the categories
labels = ['Very Low', 'Low', 'Moderate', 'Moderate High', 'High', 'Very High']

# Create a new column with the assigned categories
df['Risk level'] = pd.cut(df['Risk level'], bins=bins, labels=labels, right=False)

X = data.drop(['Timestamp', 'Email Address', 'GENDER', 'AGE', 'EDUCATION QUALIFICATION', 'Risk level'], axis=1)
y = data['Risk level']
X = X.values
y = y.values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)
classifier = SVC(kernel='linear', random_state=0)
classifier.fit(X_train, y_train)
y_predict = classifier.predict(X_test)
score = accuracy_score(y_test, y_predict)

filename = 'model.pkl'
pickle.dump(classifier, open(filename, 'wb'))


