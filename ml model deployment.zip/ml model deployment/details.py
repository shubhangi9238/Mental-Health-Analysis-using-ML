from datetime import datetime

date = datetime.now()
date=date.strftime("%d/%m/%y")

risk_discription=[
    "Maintain self-care routines, engage in relaxation techniques.",
    "Maintain self-care routines, engage in relaxation techniques, connect with loved ones, practice stress management.",
    "Utilize stress reduction techniques, engage in regular exercise, maintain social connections, consider mindfulness practices.",
    "Seek professional guidance, consider therapy options, implement healthy coping strategies, prioritize self-care.",
    "Consult a mental health professional, consider therapy or counseling, reach out to support networks, engage in self-care daily.",
    "Seek immediate professional help, involve loved ones, consider hospitalization if necessary, prioritize safety."
    ]
name="Parag Chaudhari"
age=22;