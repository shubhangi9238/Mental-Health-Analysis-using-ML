import numpy as np
from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import pickle
from details import date, age, name, risk_discription

# Create flask app
flask_app = Flask(__name__)
# model = pickle.load(open("model.pkl", "rb"))
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

result_p = '';
level = 0
labels = ['Very Low', 'Low', 'Moderate', 'Moderate High', 'High', 'Very High']
for i in range(6):
    if labels[i] == result_p:
        level = i;


@flask_app.route("/")
def Home():
    return render_template("index.html")


@flask_app.route("/login")
def login():
    return render_template("login.html")


@flask_app.route("/signup")
def signup():
    return render_template("signup.html")


@flask_app.route("/test")
def test():
    return render_template("test.html")

@flask_app.route("/prevention")
def prevention():
    return render_template("prevention.html")


@flask_app.route("/dashboard", methods=["POST"])
def dashboard():
    return render_template("dashboard.html")


@flask_app.route('/process', methods=['POST'])
def process():
    data = request.get_json()  # Assuming 'data' is a JSON object containing the array as a string
    array = np.array(data['value'])

    id_np_array = np.asarray(array)
    id_reshaped = id_np_array.reshape(1, -1)

    prediction = model.predict(id_reshaped)
    print(prediction)
    global result_p
    result_p = prediction.tolist()
    result_p = result_p[0]
    return jsonify(result="view result")


@flask_app.route('/redirect')
def redirect_example():
    return redirect(url_for('result'))

@flask_app.route('/exit')
def redirect_example_1():
    return redirect(url_for('/'))


@flask_app.route("/result")
def result():
    return render_template("result.html", risk=result_p, date=date, age=age, name=name, prevention=risk_discription[level])


# @flask_app.route("/predict", methods = ["POST"])
# def predict():
#     float_features = [float(x) for x in request.form.values()]
#     features = [np.array(float_features)]
#     prediction = model.predict(features)
#     return render_template("index.html", prediction_text = "The flower species is {}".format(prediction))

if __name__ == "__main__":
    flask_app.run(debug=True)
